#!/bin/bash
cat /flag
cat /flag.txt
cat /root/flag
cat /home/ctf/flag
